package com.mos.distributor;
import android.app.*; import android.os.*; import android.webkit.*;
public class MainActivity extends Activity {
 protected void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}